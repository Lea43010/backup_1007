function App() {
  return <div>Hello World - Minimal React Test</div>;
}

export default App;